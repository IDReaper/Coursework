from xturtle import *
setup()
